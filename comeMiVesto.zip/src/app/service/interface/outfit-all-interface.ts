

export interface Tag {
  id: any;
  name: string;
  x: number;
  y: number;
  link?: string;
  color?: string;
  outfitCategory: string;
  outfitSubCategory?: string;
}

// Interfaccia principale per l'oggetto
export interface outfit {
  id: any;
  title: string;
  description?: string;
  imageUrl: string;
  tags: Tag[];
  gender: '' | 'man' | 'woman'; // Assumendo che i valori possibili siano solo "man" o "woman"
  style: '' | 'casual' | 'elegant' | 'sporty' | 'formal'; // Assumendo alcuni stili possibili
  season: '' | 'winter' | 'spring' | 'summer' | 'autumn'; // Assumendo alcune stagioni possibili
  color?: string;
  userId: any
}

export interface wardrobesItem {
  id: number;
  userId: string;
  name: string;
  outfitCategory: string;
  outfitSubCategory: string;
  brend: string;
  color:string;
  images: string[];
}

export interface buttons {
  icon: string;
  text: string;
  actionName: string;
}[]


export const categoryCloth = [
  {
    id: "M",
    value: "Maglieria",
    parent: null
  },
  {
    id: "P",
    value: "Pantaloni",
    parent: null
  },
  {
    id: "G",
    value: "Giubbotti",
    parent: null
  },
  {
    id: "S",
    value: "Scarpe",
    parent: null
  },
  {
    id: "A",
    value: "Accessori",
    parent: null
  },
  {
    id: "AI",
    value: "Abbigliamento intimo",
    parent: null
  }]

export const subCategoryCloth= [
  {
    id: "TS",
    value: "T-shirt",
    parent: "M"
  },
  {
    id: "PO",
    value: "Polo",
    parent: "M"
  },
  {
    id: "CM",
    value: "Camicie",
    parent: "M"
  },
  {
    id: "FL",
    value: "Felpa",
    parent: "M"
  },
  {
    id: "SNK",
    value: "Sneakers",
    parent: "S"
  },
  {
    id: "BST",
    value: "Stivali",
    parent: "S"
  },
  {
    id: "SD",
    value: "Sandali",
    parent: "S"
  },
  {
    id: "MR",
    value: "Mocassini",
    parent: "S"
  },
  {
    id: "DRS",
    value: "Scarpe Eleganti",
    parent: "S"
  },
  {
    id: "BT",
    value: "Scarponcini",
    parent: "S"
  },
  {
    id: "JE",
    value: "Jeans",
    parent: "P"
  },
  {
    id: "CH",
    value: "Chino",
    parent: "P"
  },
  {
    id: "TR",
    value: "Tuta",
    parent: "P"
  },
  {
    id: "SRT",
    value: "Shorts",
    parent: "P"
  },
  {
    id: "CRG",
    value: "Cargo",
    parent: "P"
  },
  {
    id: "CL",
    value: "Classici",
    parent: "P"
  },
  {
    id: "GTP",
    value: "Giubbotti in Pelle",
    parent: "G"
  },
  {
    id: "GTS",
    value: "Giubbotti in Stoffa",
    parent: "G"
  },
  {
    id: "GTR",
    value: "Giubbotti in Tessuto Tecnico",
    parent: "G"
  },
  {
    id: "PRA",
    value: "Parka",
    parent: "G"
  },
  {
    id: "CAP",
    value: "Cappelli",
    parent: "A"
  },
  {
    id: "GLV",
    value: "Guanti",
    parent: "A"
  },
  {
    id: "SCF",
    value: "Sciarpe",
    parent: "A"
  },
  {
    id: "BLT",
    value: "Cinture",
    parent: "A"
  },
  {
    id: "WLT",
    value: "Portafogli",
    parent: "A"
  },
  {
    id: "BAG",
    value: "Borse",
    parent: "A"
  },
  {
    id: "TIE",
    value: "Cravatte",
    parent: "A"
  },
  {
    id: "SHK",
    value: "Fazzoletti da taschino",
    parent: "A"
  }
]