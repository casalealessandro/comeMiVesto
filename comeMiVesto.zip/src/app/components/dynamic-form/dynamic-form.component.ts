import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

import { DynamicFormField } from '../../service/interface/dynamic-form-field'
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AppService } from 'src/app/service/app-service';

@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.scss'],


})

export class DynamicFormComponent implements OnInit {


  @Input() service: string | undefined;
  @Output() submitFormEvent: EventEmitter<any> = new EventEmitter<any>(); //Emit all'esterno;
  form: FormGroup = new FormGroup({});
  formValues: { [key: string]: any } = {};
  dataSet: any = []
  fields: DynamicFormField[] = [];
  formShow: boolean = false
  fieldConfigs: any = [];
  constructor(private templateService: AppService, private formBuilder: FormBuilder) {


  }

  ngOnInit(): void {

    if (!this.service) {
      return
    }

    this.templateService.getFormFields(this.service).subscribe(fields => {
      this.fields = fields;
      this.initializeForm();
    });


  }

  initializeForm() {
    let formGroup = new FormGroup({});
    this.fields.forEach(field => {
      const validators = [];
      if (field.required) {
        validators.push(Validators.required);
      }
      if (typeof field.minlength != 'undefined') {
        validators.push(Validators.minLength(field.minlength));
      }
      if (typeof field.maxlength != 'undefined') {
        validators.push(Validators.maxLength(field.maxlength));
      }

      formGroup.addControl(field.name, new FormControl('', validators));
      this.initializeFormValues(field);
      if (field.type === 'selectBox') {

      }
    });

    this.form = formGroup


  }

  initializeFormValues(field: any) {

    this.formValues[field.name] = field.type === 'selectBox' && field.multiple ? [] : '';
    this.fieldConfigs[field.name] = field
  }

  onValueChange(fieldName: string, value: any) {
   
    
    
    const control = this.form.get(fieldName);

    if (control && control.value !== value) {
      /*
    { emitEvent: false }, Angular non emette l'evento valueChanges per il controllo specificato. Questo è utile in diverse situazioni come  Evitare Loop Ricorsivi
    */
      control.setValue(value, { emitEvent: false });
      this.formValues[fieldName] = value;
    }
   
    // Trigger cascade updates
    if (this.fieldConfigs[fieldName]) {
      this.updateCascadeOptions(fieldName, value);
    }
  }

  updateCascadeOptions(fieldName: string, value: any) {
    const fieldConfig = this.fieldConfigs[fieldName];
    if (fieldConfig && fieldConfig.cascadeFrom) {

      if (fieldName === fieldConfig.cascadeFrom) {

        const updatedOptions = fieldConfig.cascadeOptions[value] || [];
        this.formValues[fieldName] = updatedOptions;

      }

    }
  }


  submitForm() {
    if (this.form.valid) {
      this.submitFormEvent.emit(this.form.value);
    } else {
      console.error('Form is invalid');
    }
  }

}
