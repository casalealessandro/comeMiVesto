import { Component, ElementRef, ViewChild } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { AngularFireAuth } from '@angular/fire/compat/auth';

import { AppService } from 'src/app/service/app-service';
import { outfit, Tag } from 'src/app/service/interface/outfit-all-interface';

import { LoadingController, NavController } from '@ionic/angular';
import { ActivatedRoute, Router } from '@angular/router';
import { MyOutFitPage } from '../myoutfit/myoutfit.page';
@Component({
  selector: 'app-add-outfit',
  templateUrl: './add-outfit.page.html',
  styleUrls: ['./add-outfit.page.scss'],
})
export class AddOutfitPage {

  @ViewChild('imageContainer', { static: false }) imageContainer: ElementRef | undefined;

  image: Blob | undefined;
  tags: Tag[] = [];
  outfit!: outfit;
  title: string = '';
  description: string = '';
  showTag: boolean = false
  gender!: "" | "man" | "woman";
  style!: "" | "casual" | "elegant" | "sporty" | "formal";
  season!: "" | "winter" | "spring" | "summer" | "autumn";

  color: any;
  imgCapt: string = '';
  imgFileName: string = '';
  contentType!: any;
  myOutfit:any = MyOutFitPage
  constructor(

    private appService: AppService,
    private router: Router,
    private afAuth: AngularFireAuth,
    private loading: LoadingController
  ) {

  }


  ngOnInit() {
    this.resetOutfit();
  }

  ionViewWillEnter() {
    this.resetOutfit();
  }

  resetOutfit() {
    this.outfit = {
      id:'',
      title: '',
      description: '',
      imageUrl: '',
      tags: [],
      gender: '',
      style: '',
      season: '',
      userId: ''

    };
    this.image = undefined;

    this.title = '';
    this.description = '';
    this.showTag = false
    this.gender = ''
    this.style! = ""
    this.season! = "";
    this.color = "";
    this.imgCapt = '';
    this.imgFileName = '';
    this.contentType = null;
  }

  setImageCaptured(event: any) {
    this.image = event.img;
    this.imgFileName = event.imgName;
    this.contentType = event.contentType
  }

  setImageTagSet(event: any) {
    this.tags = event.tags as Tag[]
  }

  saveOutfit(event: any) {

    this.title = event.title;
    this.color = event.color;
    this.description = event.description;
    this.gender = event.gender;
    this.season = event.season;
    this.style = event.style;

    this.confirmOutfit()

  }

  async confirmOutfit() {

    let imageUrl = null
    if (!this.title) {
      return
    }
    if (!this.image) {
      return
    } else {
      this.loading.create({
        message: 'Salvataggio in corso...',
      })
      imageUrl = await this.appService.uploadImage(this.image, this.imgFileName, this.contentType);

    }

    const user = await this.afAuth.currentUser;
    if (user) {
      const id = Math.floor(Math.random() * (5 - 1 + 1)) + 1;;
      this.outfit = {
        id:id,
        title: this.title,
        description: this.description,
        imageUrl: imageUrl,
        tags: this.tags,
        gender: this.gender,
        style: this.style,
        season: this.season,
        color: this.color,
        userId: user.uid
      };
    }
    
    let nRND = Math.floor(Math.random() * (5 - 1 + 1)) + 1;

    const nameDoc = `outfit_${user!.uid}_${nRND}`
    let res = await this.appService.saveInCollection('outfits',undefined, this.outfit)

    if (res) {

      this.router.navigate(['/myoutfit'], {skipLocationChange: true,replaceUrl:true}).then(res => {
        this.resetOutfit()
        this.loading.dismiss();
      });
    }


  }


}
