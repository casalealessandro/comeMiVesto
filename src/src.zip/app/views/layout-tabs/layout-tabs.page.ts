import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-layout-tabs',
  templateUrl: './layout-tabs.page.html',
  styleUrls: ['./layout-tabs.page.scss'],
})
export class LayoutTabsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
