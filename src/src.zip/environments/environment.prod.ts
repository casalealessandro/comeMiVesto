export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBNWYDp0fPgLU0npKMC0RoS6C14fHp2mpk",
    authDomain: "comemivesto-5e5f9.firebaseapp.com",
    projectId: "comemivesto-5e5f9",
    storageBucket: "comemivesto-5e5f9.appspot.com",
    messagingSenderId: "124990581718",
    appId: "1:124990581718:web:51c8cbf699123bd0e8d277",
    measurementId: "G-8D9XBPY0Q7"
  }
};
